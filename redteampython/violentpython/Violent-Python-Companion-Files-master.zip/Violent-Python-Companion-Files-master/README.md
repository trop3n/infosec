# Violent Python scripts

Some of the scripts are updated for python3 support 

Rest will be done soon.
